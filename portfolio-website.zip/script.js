// JavaScript for future interactions
console.log('Portfolio loaded');
